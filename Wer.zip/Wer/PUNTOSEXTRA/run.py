from flask import Flask, render_template, url_for, request, redirect, session, jsonify, make_response
from lexico import *

app = Flask(__name__)
@app.route('/')
def index():
    lexical = Lexico()
    lexical.analizarLex("FO i IN RANGEr(5):")
    resultado = lexical.resultadoLexema
    cantidades = lexical.cantidadTipos
    return render_template('index.html', resultado = resultado, cantidades = cantidades)


if __name__ == '__main__':
    app.run(debug=True)