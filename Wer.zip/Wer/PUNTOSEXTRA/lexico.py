import ply.lex as lex

class Lexico:
    def __init__(self):
        self.linea = 1
        self.resultadoLexema =[]
        self.cantidadTipos = [0,0,0,0,0,0]
        #Tokens
        self.tokens = ('PUNTODOBLE','ENTERO','IPAREN',
                       'RPAREN','RANGE','I','IN','FOR')
  
        self.tipo = ""
        self.t_PUNTODOBLE = r'\:'
        self.t_IPAREN = r'\('
        self.t_RPAREN = r'\)'
        self.t_FOR = r'\bFOR\b'
        self.t_RANGE = r'\bRANGE\b'
        self.t_IN = r'\bIN\b'
        self.t_I = r'\bi\b'
                
        self.lexer = lex.lex(module=self)

    def t_ENTERO(self,t):
        r'\b\d+\b'
        self.tipo = "NUMERO"
        self.cantidadTipos[2] = self.cantidadTipos[2] + 1
        return t

    def t_newline(self,t):
        r'\n+'
        t.lexer.lineno += len(t.value)

    t_ignore  = ' \t'

    def t_error(self,t):
        self.cantidadTipos[5] = self.cantidadTipos[5] + 1
        estado = {
            "token": "DESCONOCIDO",
            "lexema": str(t.value),
            "linea": str(self.linea)
        }
        cadena = str(t.value)
        valor = len(cadena)
        t.lexer.skip(valor)
        self.resultadoLexema.append(estado)

    def analizarLex(self,data):
        self.linea = 1
        lineasAux =  data.split("\n")
        for lineaAnalicis in lineasAux:  
            datos = lineaAnalicis.split(" ")
            for dato in datos:
                self.lexer.input(dato)
                while True:
                    tok = self.lexer.token()
                    if not tok:
                        break
                    self.asignarTipo(tok.value)
                    estado = {
                        "token": self.tipo,
                        "lexema": str(tok.value), 
                        "linea": str(self.linea)
                    }
                    self.resultadoLexema.append(estado)
            self.linea += 1

    def asignarTipo(self, dato):
        if dato == "i":
            self.cantidadTipos[0] = self.cantidadTipos[0] + 1
            self.tipo = "ID"
        elif (dato == "FOR") or (dato == "IN") or (dato == "RANGE"):
            self.cantidadTipos[1] = self.cantidadTipos[1] + 1
            self.tipo = "RESERVADA"
        elif (dato == ")") or (dato == "("):
            self.cantidadTipos[3] = self.cantidadTipos[3] + 1
            self.tipo = "DELIMITADOR"
        elif (dato == ":") or (dato == ";"):
            self.cantidadTipos[4] = self.cantidadTipos[4] + 1
            self.tipo = "SIMBOLO"

