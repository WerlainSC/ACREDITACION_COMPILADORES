import ply.yacc as yacc
from lexico import *

#FINAL FINAL
class Sintactico:
    def __init__(self):
        self.lexi = Lexico()
        self.tokens = self.lexi.tokens
        self.parser = yacc.yacc(module=self)
        self.sintacticResult = ""
        self.error = ""

    #INICIO DE LA GRAMATICA
    def p_program(self, p):
        'program : FOR ID IN RANGE IPAREN ENTERO RPAREN PUNTODOBLE'        
        p[0] = p [1]

    def p_error(self,p):   
        if p:
            self.error = p
            print("sintactico.py IF -> Error en token ", p)
        else:
            self.error = "EOF"
            print("sintactico.py IF -> Error: se encontró EOF")

#BUILD PARSER
    def evasin(self, dato):
        self.parser.parse(dato)
        self.lexi.analizarLex(dato)
        print ("tokens",self.lexi.resultadoLexema)

sintactico = Sintactico()
palabra = input ("INGRESAR PALABRA")
sintactico.evasin (palabra)


